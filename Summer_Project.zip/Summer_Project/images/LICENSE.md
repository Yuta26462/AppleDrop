#LICENSE
・cat.png
くまみね工房
https://kumamine.blogspot.com/

・apple.png,greenapple.png,purpleapple.png,yellowapple.png
フリーイラストの「かくぬる素材工房」
https://knsoza1.com/

・background.png,pause.png
かわいいフリー素材集 いらすとや
https://www.irasutoya.com/